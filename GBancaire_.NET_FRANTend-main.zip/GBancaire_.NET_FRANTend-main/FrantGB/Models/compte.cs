﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FrantGB.Models
{
    public class compte
    {
        public int Id { get; set; }
        public float solde { get; set; }
        public string nom { get; set; }
    }
}